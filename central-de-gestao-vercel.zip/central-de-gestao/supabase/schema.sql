create table if not exists public.docs (
  collection text not null,
  id text not null,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  primary key (collection, id)
);
alter table public.docs enable row level security;
drop policy if exists "admin autenticado" on public.docs;
create policy "admin autenticado" on public.docs
  for all to authenticated using (true) with check (true);

-- Dados fictícios de demonstração (pode apagar depois)
insert into public.docs (collection, id, data) values
 ('companies','sicredi','{"name":"Sicredi","discount":0,"notes":""}'),
 ('members','demo-joao', jsonb_build_object('name','João','plate','ABC12344','amount',100,'companyId','sicredi','day',10,'phone','','active',true,'demo',true,'notes','Registro fictício de demonstração','createdAt',to_char(now(),'YYYY-MM-01')))
on conflict do nothing;
